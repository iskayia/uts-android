package com.siska.uts_android;

public class Prabot {
    String id, nama, deskripsi, harga;

    public Prabot(String id, String nama, String deskripsi, String harga) {
        this.id = id;
        this.nama = nama;
        this.deskripsi = deskripsi;
        this.harga = harga;
    }

    public String getId() {
        return id;
    }

    public String getNama() {
        return nama;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public String getHarga() {
        return harga;
    }
}
